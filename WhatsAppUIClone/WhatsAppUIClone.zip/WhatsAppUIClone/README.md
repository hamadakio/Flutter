# WhatsApp UI Clone with Flutter

A WhatsApp UI clone using flutter, almost similar to the original one. 

Thanks to <a href="https://github.com/iampawan">Pawan kumar</a> for his tutorials and videos for flutter. 

Star this repo if you like it.

# ScreenShot
<img src="https://github.com/amangautam1/WhatsAppUIClone/blob/master/images/Screenshot_2018-05-13-00-01-14-278_com.yourcompany.whatsappclone.png" height=300 width=170 />

# Demo
<img src="images/demo.gif" height=300 width=170/>



## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

## Support on Beerpay
Hey dude! Help me out for a couple of :beers:!

[![Beerpay](https://beerpay.io/amangautam1/WhatsAppUIClone/badge.svg?style=beer-square)](https://beerpay.io/amangautam1/WhatsAppUIClone)  [![Beerpay](https://beerpay.io/amangautam1/WhatsAppUIClone/make-wish.svg?style=flat-square)](https://beerpay.io/amangautam1/WhatsAppUIClone?focus=wish)